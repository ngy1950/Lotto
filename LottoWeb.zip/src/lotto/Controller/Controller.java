package lotto.Controller;

public class Controller {

}
