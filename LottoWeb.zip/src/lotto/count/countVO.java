package lotto.count;

public class countVO {
	private int lottoNum;
	private int lottoWin;
	private int bouns;
	
	public int getLottoNum() {
		return lottoNum;
	}
	public void setLottoNum(int lottoNum) {
		this.lottoNum = lottoNum;
	}
	public int getLottoWin() {
		return lottoWin;
	}
	public void setLottoWin(int lottoWin) {
		this.lottoWin = lottoWin;
	}
	public int getBouns() {
		return bouns;
	}
	public void setBouns(int bouns) {
		this.bouns = bouns;
	}
	
	

}
